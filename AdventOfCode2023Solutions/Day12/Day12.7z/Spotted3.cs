﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventOfCode2023Solutions.Day12
{
    internal class Spotted3
    {
        private string _Value;
        private int _Index = 0;
        private int _OriginalIndex = 0;
        private Spotted3[] _Parts = [];
        private int _Multiplier = 1;
        private List<int> _MemoryGroups = [];
        private bool _Locked = false;
        private List<int> _MustContainMemory = [];

        public List<int> MemoryGroups { get { return _MemoryGroups; } }

        public int Multiplier { get { return _Multiplier; } set { _Multiplier = value; } }
        public string Value { get { return _Value; } }
        public int Length { get { return _Value.Length; } }

        public int IterateIndex { get { return _Index; } }
        public int OriginalIndex { get { return _OriginalIndex; } }

        public bool Locked { get { return _Locked; } }

        public List<int> MustContainMemory 
        { get { return _MustContainMemory; } }

        public Spotted3(string value, int originalIndex)
        {
            _Value = value;
            _OriginalIndex = originalIndex;
        }

        public int[] PossibleIndexes(Memory3 memoryGroup)
        {
            List<int> indexes = [];

            for (int index = 0; index <= _Value.Length - memoryGroup.Length; index++)
            {
                if (CheckIndex(index, memoryGroup.Length))
                {
                    indexes.Add(_OriginalIndex + index);
                }
            }

            if (0 < indexes.Count)
            {
                List<Memory3> memoryGroups = new List<Memory3>(_MemoryGroups.Count + 1);
                int i = 0;
                while (i < _MemoryGroups.Count)
                {
                    memoryGroups[i] = _MemoryGroups[i];

                    i++;
                }
                memoryGroups[i] = memoryGroup;

                _MemoryGroups = memoryGroups;
            }

            return indexes.ToArray();
        }

        public bool CanContain(Memory3[] memoryGroups)
        {
            int collectiveLength = -1;

            foreach (Memory3 memoryGroup in memoryGroups)
            {
                collectiveLength += 1 + memoryGroup.Length;
            }

            return collectiveLength <= Length;
        }

        private bool CheckIndex(int index, int length)
        {
            bool success = true;

            if (0 < index && _Value[index-1] == '#')
            {
                success = false;
            }

            if (index + length < _Value.Length && _Value[index + length] == '#')
            {
                success = false;
            }

            return success;
        }

        public void Lock()
        {
            _Locked = true;
            // TODO: send cut wave

        }
    }
}
