﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace AdventOfCode2023Solutions.Day12
{
    internal class SpringStatusSheet3
    {
        private string _MemoryString;
        private string _SpottedString;
        private Spotted3[] _SpottedGroups;
        private Memory3[] _MemoryGroups;
        //private Regex _StatusRegex;
        //private Regex _GroupsRegex;
        private List<ArrangementPart> _Arrangements = [];
        private long _ArrangementsCount = 0;
        private int _RequiredIndexI = 0;
        private RequiredIndex[] _RequiredIndexes;
        private Regex _SpottedPartsPattern = new Regex(@"[\#\?]+");

        public string MemoryString { get { return _MemoryString; } }
        public string SpottedString { get { return _SpottedString; } }
        public List<ArrangementPart> Arrangements { get { return _Arrangements; } }
        public long ArrangementsCount { get { return _ArrangementsCount; } }

        public SpringStatusSheet3(string spotted, string damagedGroups) 
        {
            _SpottedString = spotted;
            _MemoryString = damagedGroups;

            BuildArrangements();
            //_Arrangements.Add(new ArrangementPart(ArrangementPart.NextGroupIndex(_DamagedGroups[0], 0, in _Status), in _Status, 0, _DamagedGroups ) );

            //SetArrangements(0, new int[_DamagedGroups.Length]);

            //_ArrangementsCount = CountArrangements(0, new int[_DamagedGroups.Length]);

            //long c = CalcArrangements();
            //_ArrangementsCount = c;
        }
        private Memory3[] BuildSpringSheetMemoryParts()
        {
            return _MemoryString.Split(',').Select(a => new Memory3(int.Parse(a))).ToArray();
        }
        private Spotted3[] BuildSpringSheetSpottedParts()
        {
            return _SpottedPartsPattern.Matches(_SpottedString).Select((a,b) => new Spotted3(a.Value, b)).ToArray();
        }

        private Regex BuildStatusRegex()
        {
            string damaged = @"\#";
            string operational = @"\.";
            string either = @"[\.\#]";
            StringBuilder pattern = new();

            for(int i = 0; i < _SpottedString.Length; i++)
            {
                char sign = _SpottedString[i];

                switch (sign)
                {
                    case '.':
                        pattern.Append(operational);
                        break;
                    case '#':
                        pattern.Append(damaged);
                        break;
                    case '?':
                        pattern.Append(either);
                        break;
                    default:
                        pattern.Append(@"");
                        break;
                }
            }

            return new Regex(pattern.ToString());
        }

        private Regex BuildGroupsRegex()
        {
            string damaged = @"\#";
            string operational = @"\.*";
            StringBuilder pattern = new();

            pattern.Append(operational);
            for (int i = 0; i < _MemoryString.Length; i++)
            {
                if (0<i)
                {
                    pattern.Append(@"\.+");
                }

                pattern.Append(damaged);
                pattern.Append('{');
                pattern.Append(_MemoryString[i].Length);
                pattern.Append('}');
            }
            pattern.Append(operational);

            return new Regex(pattern.ToString());
        }

        private RequiredIndex[] BuildRequiredIndex()
        {
            Regex pattern = new Regex(@"\#+");
            RequiredIndex[] results = pattern.Matches(_SpottedString).Select(a => new RequiredIndex() { Index = a.Index, Length = a.Length }).ToArray();
            return results;
        }

        private void BuildArrangements()
        {
            _MemoryGroups = BuildSpringSheetMemoryParts();
            _SpottedGroups = BuildSpringSheetSpottedParts();
            int nextSpottedIndex = Array.FindIndex(_SpottedGroups, a => a.Locked == false);
            int radius = (int)Math.Ceiling(_MemoryGroups.Length * 0.5);

            //_RequiredIndexes = BuildRequiredIndex();
            
            for (int memoryI = 0; memoryI < _MemoryGroups.Length; memoryI++)
            {
                // if previous memory's first spottedI is higher than this spottedI -> then catch up this spottedI
                if (0 < memoryI && nextSpottedIndex < _MemoryGroups[memoryI - 1].SpottedGroups.FirstOrDefault(0)) 
                {
                    nextSpottedIndex = _MemoryGroups[memoryI - 1].SpottedGroups.FirstOrDefault(0);
                }

                // if previous memory's first spottedI is this, unless we can both fit in this spottedI -> then skip this spottedI
                int[] allWithSameFirst;
                {
                    int[] temp = _MemoryGroups.Select((a, b) => new { Value = a, Index = b }).Where(a => a.Value.SpottedGroups.First() == nextSpottedIndex).Select(a => a.Index).ToArray();
                    allWithSameFirst = [temp.Length +1];
                    temp.CopyTo(allWithSameFirst, 0);
                    allWithSameFirst[temp.Length] = memoryI;
                }
                
                if (0 < memoryI && nextSpottedIndex == _MemoryGroups[memoryI - 1].SpottedGroups.FirstOrDefault(0))
                {
                    _SpottedGroups[nextSpottedIndex].CanContain( allWithSameFirst.Select(a=>_MemoryGroups[a]).ToArray());
                }


                for (int spottedI = nextSpottedIndex; spottedI < _SpottedGroups.Length; spottedI++)
                {
                    if (!_SpottedGroups[spottedI].Locked) 
                    {
                        int[] fit = _SpottedGroups[spottedI].CanContain([_MemoryGroups[memoryI]]);
                        _MemoryGroups[memoryI].SpottedGroups.AddRange(fit);

                        if (!_MemoryGroups[memoryI].SpottedGroups.Contains(spottedI))
                        {
                            _MemoryGroups[memoryI].SpottedGroups.Add(spottedI);
                        }
                        if (!_SpottedGroups[spottedI].MemoryGroups.Contains(memoryI))
                        {
                            _SpottedGroups[spottedI].MemoryGroups.Add(memoryI);
                        }
                    }
                }

                if (1 == _MemoryGroups[memoryI].SpottedGroups.Count)
                {
                    var spottedGroup = _MemoryGroups[memoryI].SpottedGroups.First();
                    _SpottedGroups[spottedGroup].Lock();
                    nextSpottedIndex++;
                }
            }

        }

        private void SetDamagedGroupsIndexes()
        {
            int statusIndex = 0;

            for (int damagedGroupsIndex = 0; damagedGroupsIndex < _MemoryString.Length; damagedGroupsIndex++)
            {
                if (0 < damagedGroupsIndex) 
                {
                    statusIndex = _MemoryString[damagedGroupsIndex-1].Indexes[0] + _MemoryString[damagedGroupsIndex - 1].Length + 1;
                }

                statusIndex = CheckGroupIndex(_MemoryString[damagedGroupsIndex], statusIndex);
                if (-1 < statusIndex)
                {
                    _MemoryString[damagedGroupsIndex].Indexes.Add(statusIndex);
                }
                else
                {
                    throw new Exception("No room for damaged group in sheet status");
                }
            }

            int lastGroupI = _MemoryString.Length - 1;
            statusIndex = _SpottedString.Length - _MemoryString[lastGroupI].Length;

            for (int damagedGroupsIndex = lastGroupI; -1 < damagedGroupsIndex; damagedGroupsIndex--)
            {
                if (damagedGroupsIndex < lastGroupI)
                {
                    statusIndex = _MemoryString[damagedGroupsIndex + 1].Indexes.Last() - _MemoryString[damagedGroupsIndex].Length - 1;
                }

                while (_MemoryString[damagedGroupsIndex].Indexes[0] < statusIndex)
                {
                    if (statusIndex == CheckGroupIndex(_MemoryString[damagedGroupsIndex], statusIndex))
                    {
                        _MemoryString[damagedGroupsIndex].Indexes.Add(statusIndex);
                    }

                    statusIndex--;
                }

                _MemoryString[damagedGroupsIndex].Indexes.Sort();
            }

        }

        private int CheckGroupIndex(Memory3 group, int index)
        {
            Match result = group.Pattern.Match(_SpottedString, index);

            if (result.Success)
            {

            }

            return result.Success ? result.Index : -1;
        }

        /*
                private long CalcArrangements()
                {
                    List<int> used = [];
                    int[] doubleUsed = new int[_DamagedGroups.Length];
                    long cm = 1;
                    int ca = 0;

                    for (int i = 0; i < _DamagedGroups.Length; i++)
                    {
                        foreach (int u in _DamagedGroups[i].Indexes)
                        {
                            if (!used.Contains(u))
                            {
                                used.Add(u);
                            }
                            else
                            {
                                doubleUsed[i]++;
                            }
                        }
                    }

                    for (int i = 0; i < _DamagedGroups.Length; i++)
                    {
                        int multi = _DamagedGroups[i].Indexes.Count;
                        int add = 0;

                        multi -= doubleUsed[i];
                        add += doubleUsed[i];

                        cm *= multi;
                        ca += add;
                    }

                    return cm+ca;
                }

                private void SetArrangements(int damagedGroupsIndex, int[] damagedGroupsIndexes)
                {
                    if (damagedGroupsIndex < damagedGroupsIndexes.Length - 1)
                    {
                        for (int i = 0; i < _DamagedGroups[damagedGroupsIndex].Indexes.Count; i++)
                        {
                            damagedGroupsIndexes[damagedGroupsIndex] = i;
                            SetArrangements(damagedGroupsIndex + 1, damagedGroupsIndexes);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < _DamagedGroups[damagedGroupsIndex].Indexes.Count; i++)
                        {
                            damagedGroupsIndexes[damagedGroupsIndex] = i;

                            BuildArrangement(damagedGroupsIndexes);

                        }
                    }
                }

                private void BuildArrangement(int[] damagedGroupsIndexes)
                {
                    //if (!TestCase(damagedGroupsIndexes)) { return; }

                    StringBuilder sb = new();
                    int damagedGroupsIndex = -1;
                    int gStart = -1;
                    int gEnd = -1;

                    for (int statusIndex = 0; statusIndex < _Status.Length; statusIndex++)
                    {
                        if (gEnd < statusIndex && damagedGroupsIndex+1 < damagedGroupsIndexes.Length)
                        {
                            damagedGroupsIndex++;
                            gStart = _DamagedGroups[damagedGroupsIndex].Indexes[damagedGroupsIndexes[damagedGroupsIndex]];
                            gEnd = gStart + _DamagedGroups[damagedGroupsIndex].Length - 1;
                        }

                        if (gStart <= statusIndex && statusIndex <= gEnd)
                        {
                            sb.Append('#');
                        }
                        else
                        {
                            sb.Append('.');
                        }

                    }

                    string test = sb.ToString();

                    if (_StatusRegex.Match(test).Success && _GroupsRegex.Match(test).Success)
                    {
                        _Arrangements.Add(test);
                        _ArrangementsCount++;
                    }


                }

                private int CountArrangements(int damagedIndex, int[] damagedIndexes)
                {
                    int sum = 0;

                    if (damagedIndex < damagedIndexes.Length - 1)
                    {
                        for (int i = 0; i < _DamagedGroups[damagedIndex].Indexes.Count; i++)
                        {
                            damagedIndexes[damagedIndex] = i;
                            sum += CountArrangements(damagedIndex+1, damagedIndexes);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < _DamagedGroups[damagedIndex].Indexes.Count; i++)
                        {
                            damagedIndexes[damagedIndex] = i;

                            sum += TestCase(damagedIndexes) ? 1 : 0;

                        }
                    }

                    return sum;
                }

                private bool TestCase(int[] damagedGroupsIndexes)
                {
                    int damagedGroupsIndex = 0;

                    for (int statusIndex = 0; statusIndex < _Status.Length; statusIndex++)
                    {
                        int index = _DamagedGroups[damagedGroupsIndex].Indexes[damagedGroupsIndexes[damagedGroupsIndex]];

                        if (index < statusIndex) { return false; }

                        while (statusIndex < index)
                        {
                            if ('#' == _Status[statusIndex]) { return false; }
                            statusIndex++;
                        }

                        statusIndex = index + _DamagedGroups[damagedGroupsIndex].Length;

                        if (statusIndex < _Status.Length)
                        {
                            if ('#' == _Status[statusIndex]) { return false; }
                        }
                        else if (damagedGroupsIndex < damagedGroupsIndexes.Length -1 ) { return false; }
                        else { break; }

                        damagedGroupsIndex++;

                        if (damagedGroupsIndex >= damagedGroupsIndexes.Length)
                        {
                            while (statusIndex < _Status.Length)
                            {
                                if ('#' == _Status[statusIndex]) { return false; }
                                statusIndex++;
                            }
                        }
                    }

                    return true;
                }

                private void RemoveBadGroupIndexes()
                {
                    for (int groupIndex = 0; groupIndex < _DamagedGroups.Length; groupIndex++)
                    {

                    }
                }
        */
    }
}
