﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace AdventOfCode2023Solutions.Day12
{
    internal class SpringStatusSheet2
    {
        private Memory3[] _DamagedGroups;
        private string _Status;
        private Regex _StatusRegex;
        private Regex _GroupsRegex;
        private List<string> _Arrangements = [];
        private long _ArrangementsCount = 0;
        private int _RequiredIndexI = 0;
        private RequiredIndex[] _RequiredIndexes;

        public Memory3[] DamagedGroups { get { return _DamagedGroups; } }
        public string Status { get { return _Status; } }
        public List<string> Arrangements { get { return _Arrangements; } }
        public long ArrangementsCount { get { return _ArrangementsCount; } }

        public SpringStatusSheet2(string status, Memory3[]  damagedGroups) 
        {
            _Status = status;
            _DamagedGroups = damagedGroups;

            _StatusRegex = BuildStatusRegex();
            _GroupsRegex = BuildGroupsRegex();
            _RequiredIndexes = BuildRequiredIndex();

            SetDamagedGroupsIndexes();
            
            SetArrangements(0, new int[_DamagedGroups.Length]);

            //_ArrangementsCount = CountArrangements(0, new int[_DamagedGroups.Length]);

            _ArrangementsCount = CalcArrangements();
        }

        private Regex BuildStatusRegex()
        {
            string damaged = @"\#";
            string operational = @"\.";
            string either = @"[\.\#]";
            StringBuilder pattern = new();

            for(int i = 0; i < _Status.Length; i++)
            {
                char sign = _Status[i];

                switch (sign)
                {
                    case '.':
                        pattern.Append(operational);
                        break;
                    case '#':
                        pattern.Append(damaged);
                        break;
                    case '?':
                        pattern.Append(either);
                        break;
                    default:
                        pattern.Append(@"");
                        break;
                }
            }

            return new Regex(pattern.ToString());
        }

        private Regex BuildGroupsRegex()
        {
            string damaged = @"\#";
            string operational = @"\.*";
            StringBuilder pattern = new();

            pattern.Append(operational);
            for (int i = 0; i < _DamagedGroups.Length; i++)
            {
                if (0<i)
                {
                    pattern.Append(@"\.+");
                }

                pattern.Append(damaged);
                pattern.Append('{');
                pattern.Append(_DamagedGroups[i].Length);
                pattern.Append('}');
            }
            pattern.Append(operational);

            return new Regex(pattern.ToString());
        }

        private RequiredIndex[] BuildRequiredIndex()
        {
            Regex pattern = new Regex(@"\#+");

            MatchCollection results = pattern.Matches(_Status);

            return results.Select(a=> new RequiredIndex() { Index = a.Index, Length = a.Length }).ToArray();
        }

        private void SetDamagedGroupsIndexes()
        {
            int statusIndex = 0;

            for (int damagedGroupsIndex = 0; damagedGroupsIndex < _DamagedGroups.Length; damagedGroupsIndex++)
            {
                if (0 < damagedGroupsIndex) 
                {
                    statusIndex = _DamagedGroups[damagedGroupsIndex-1].SpottedGroups[0] + _DamagedGroups[damagedGroupsIndex - 1].Length + 1;
                }

                statusIndex = CheckGroupIndex(_DamagedGroups[damagedGroupsIndex], statusIndex);
                if (-1 < statusIndex)
                {
                    _DamagedGroups[damagedGroupsIndex].SpottedGroups.Add(statusIndex);
                }
                else
                {
                    throw new Exception("No room for damaged group in sheet status");
                }
            }

            int lastGroupI = _DamagedGroups.Length - 1;
            statusIndex = _Status.Length - _DamagedGroups[lastGroupI].Length;

            for (int damagedGroupsIndex = lastGroupI; -1 < damagedGroupsIndex; damagedGroupsIndex--)
            {
                if (damagedGroupsIndex < lastGroupI)
                {
                    statusIndex = _DamagedGroups[damagedGroupsIndex + 1].SpottedGroups.Last() - _DamagedGroups[damagedGroupsIndex].Length - 1;
                }

                while (_DamagedGroups[damagedGroupsIndex].SpottedGroups[0] < statusIndex)
                {
                    if (statusIndex == CheckGroupIndex(_DamagedGroups[damagedGroupsIndex], statusIndex))
                    {
                        _DamagedGroups[damagedGroupsIndex].SpottedGroups.Add(statusIndex);
                    }

                    statusIndex--;
                }

                _DamagedGroups[damagedGroupsIndex].SpottedGroups.Sort();
            }

        }

        private long CalcArrangements()
        {
            List<int> used = [];
            int[] doubleUsed = new int[_DamagedGroups.Length];
            long cm = 1;
            int ca = 0;

            for (int i = 0; i < _DamagedGroups.Length; i++)
            {
                foreach (int u in _DamagedGroups[i].SpottedGroups)
                {
                    if (!used.Contains(u))
                    {
                        used.Add(u);
                    }
                    else
                    {
                        doubleUsed[i]++;
                    }
                }
            }

            for (int i = 0; i < _DamagedGroups.Length; i++)
            {
                int multi = _DamagedGroups[i].SpottedGroups.Count;
                int add = 0;

                multi -= doubleUsed[i];
                add += doubleUsed[i];

                cm *= multi;
                ca += add;
            }

            return cm+ca;
        }

        private int CheckGroupIndex(Memory3 group, int index)
        {
            Match result = group.Pattern.Match(_Status, index);

            if (result.Success && 0 < _RequiredIndexes.Where(a => a.Index < result.Index).ToArray().Length) 
            {
                return result.Index;
            }
            return -1;
        }

        private void SetArrangements(int damagedGroupsIndex, int[] damagedGroupsIndexes)
        {
            if (damagedGroupsIndex < damagedGroupsIndexes.Length - 1)
            {
                for (int i = 0; i < _DamagedGroups[damagedGroupsIndex].SpottedGroups.Count; i++)
                {
                    damagedGroupsIndexes[damagedGroupsIndex] = i;
                    SetArrangements(damagedGroupsIndex + 1, damagedGroupsIndexes);
                }
            }
            else
            {
                for (int i = 0; i < _DamagedGroups[damagedGroupsIndex].SpottedGroups.Count; i++)
                {
                    damagedGroupsIndexes[damagedGroupsIndex] = i;

                    BuildArrangement(damagedGroupsIndexes);

                }
            }
        }

        private void BuildArrangement(int[] damagedGroupsIndexes)
        {
            //if (!TestCase(damagedGroupsIndexes)) { return; }

            StringBuilder sb = new();
            int damagedGroupsIndex = -1;
            int gStart = -1;
            int gEnd = -1;

            for (int statusIndex = 0; statusIndex < _Status.Length; statusIndex++)
            {
                if (gEnd < statusIndex && damagedGroupsIndex+1 < damagedGroupsIndexes.Length)
                {
                    damagedGroupsIndex++;
                    gStart = _DamagedGroups[damagedGroupsIndex].SpottedGroups[damagedGroupsIndexes[damagedGroupsIndex]];
                    gEnd = gStart + _DamagedGroups[damagedGroupsIndex].Length - 1;
                }

                if (gStart <= statusIndex && statusIndex <= gEnd)
                {
                    sb.Append('#');
                }
                else
                {
                    sb.Append('.');
                }

            }

            string test = sb.ToString();

            if (_StatusRegex.Match(test).Success && _GroupsRegex.Match(test).Success)
            {
                _Arrangements.Add(test);
                _ArrangementsCount++;
            }

            
        }

        private int CountArrangements(int damagedIndex, int[] damagedIndexes)
        {
            int sum = 0;
            
            if (0 == damagedIndex) { _RequiredIndexI = 0; }
            int requiredIndexMem = _RequiredIndexI;

            
            for (int i = 0; i < _DamagedGroups[damagedIndex].SpottedGroups.Count; i++)
            {
                damagedIndexes[damagedIndex] = i;
                _RequiredIndexI = requiredIndexMem;

                if (0 != damagedIndex && 
                    _DamagedGroups[damagedIndex].SpottedGroups[i] <= _DamagedGroups[damagedIndex-1].SpottedGroups[damagedIndexes[damagedIndex - 1]] + _DamagedGroups[damagedIndex - 1].Length) 
                {
                    continue;
                }

                if (_RequiredIndexI < _RequiredIndexes.Length &&
                    _RequiredIndexes[_RequiredIndexI].Index < _DamagedGroups[damagedIndex].SpottedGroups[i]) 
                {
                     break;
                }

                while (_RequiredIndexI < _RequiredIndexes.Length &&
                        _RequiredIndexes[_RequiredIndexI].Index >= _DamagedGroups[damagedIndex].SpottedGroups[i] &&
                        _RequiredIndexes[_RequiredIndexI].Index + _RequiredIndexes[_RequiredIndexI].Length <= _DamagedGroups[damagedIndex].SpottedGroups[i] + _DamagedGroups[damagedIndex].Length)
                {
                    _RequiredIndexI++;
                }

                if (damagedIndex < damagedIndexes.Length - 1)
                {
                    sum += CountArrangements(damagedIndex+1, damagedIndexes);
                }
                else
                {
                    if (_RequiredIndexI < _RequiredIndexes.Length)
                    {
                        break;
                    }
                    else
                    {
                        sum++;
                    }

                    //sum += TestCase(damagedIndexes) ? 1 : 0;
                }

            }

            return sum;
        }

        private bool TestCase(int[] damagedGroupsIndexes)
        {
            int damagedGroupsIndex = 0;
            int requiredIndex = 0;
            //int requiredIndexLength = _RequiredIndexes.Count;
            bool requiredUsed = false;

            foreach (RequiredIndex required in _RequiredIndexes)
            {
                while (damagedGroupsIndex < damagedGroupsIndexes.Length)
                {
                    if (required.Index >= _DamagedGroups[damagedGroupsIndex].SpottedGroups[damagedGroupsIndexes[damagedGroupsIndex]] &&
                        required.Index + required.Length <= _DamagedGroups[damagedGroupsIndex].SpottedGroups[damagedGroupsIndexes[damagedGroupsIndex]] + _DamagedGroups[damagedGroupsIndex].Length)
                    {
                        requiredUsed = true;
                        break;
                    }
                    damagedGroupsIndex++;
                }

                if (!requiredUsed)
                {
                    return false;
                }
                else
                {
                    requiredUsed = false;
                }

                requiredIndex++;
            }

            return true;
        }

        private void RemoveBadGroupIndexes()
        {
            int requiredIndex = 0;
            int requiredIndexLength = _RequiredIndexes.Length;
            bool[] requiredUsed = new bool[requiredIndexLength];
            foreach (RequiredIndex required in _RequiredIndexes)
            {
                for (int groupIndex = 0; groupIndex < _DamagedGroups.Length; groupIndex++)
                {
                    
                }
            }
            
        }
    }
}
