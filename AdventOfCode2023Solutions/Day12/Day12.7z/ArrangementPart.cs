﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AdventOfCode2023Solutions.Day12
{
    internal class ArrangementPart
    {
        private List<ArrangementPart> _Arrangements = [];
        private int _Index;
        private int _Length;

        public List<ArrangementPart> Arrangements {  get { return _Arrangements; } }
        public int Index { get { return _Index; } }
        public int Length { get { return _Length; } }

        public ArrangementPart(int index, in string status, int damagedGroupIndex,  Memory3[] damagedGroups)
        {
            _Index = index;
            _Length = damagedGroups[damagedGroupIndex].Length;
        }

        public void BuildArrangements()
        {
            int statusIndex = 0;
            _RequiredIndexI = 0;

            // for each damaged group
            for (int damagedGroupsIndex = 0; damagedGroupsIndex < _DamagedGroups.Length; damagedGroupsIndex++)
            {
                // if not first group, start 1 after previous group
                if (0 < damagedGroupsIndex)
                {
                    statusIndex = _DamagedGroups[damagedGroupsIndex - 1].Indexes[0] + _DamagedGroups[damagedGroupsIndex - 1].Length + 1;
                }

                // jump to next found group
                statusIndex = CheckGroupIndex(_DamagedGroups[damagedGroupsIndex], statusIndex);

                // if group found, add it, else error
                if (-1 < statusIndex)
                {
                    _DamagedGroups[damagedGroupsIndex].Indexes.Add(statusIndex);
                }
                else
                {
                    throw new Exception("No room for damaged group in sheet status");
                }
            }
        }

        public static int NextGroupIndex(Memory3 group, int index, in string status)
        {
            Match result = group.Pattern.Match(status, index);

            return result.Success ? result.Index : -1;
        }
    }
}
