﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace AdventOfCode2023Solutions.Day12
{
    internal class Memory3
    {
        private int _Length = 0;
        private List<int> _SpottedGroups = [];
        private readonly Regex _Pattern;

        public int Length { get { return _Length; } }
        public List<int> SpottedGroups { get {  return _SpottedGroups; } }
        public int MinIndex { get { return _SpottedGroups[0]; } }
        public int MaxIndex { get { return _SpottedGroups[_SpottedGroups.Count-1]; } }
        public Regex Pattern { get { return _Pattern; } }

        public Memory3(int length)
        {
            _Length = length;

            StringBuilder pattern = new();

            pattern.Append(@"(?<!\#)");
            pattern.Append(@"[\#\?]");
            pattern.Append('{');
            pattern.Append(_Length);
            pattern.Append('}');
            pattern.Append(@"(?!\#)");

            _Pattern = new Regex(pattern.ToString());
        }
    }
}
